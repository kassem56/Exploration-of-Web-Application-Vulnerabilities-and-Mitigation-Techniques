<html>
<head>
    <title>GET Login Handle</title>
</head>
<body>
<?php
    $host = "localhost"; // Host name
    $username = "root"; // MySQL username
    $password = ""; // MySQL password
    $db_name = "project_csec"; // Database name
    $tbl_name = "users"; // Table name
    $max_attempts = 2; // Max attempts per hour
    $lockout_time = 3600; // Lockout for 1 hour

    // Create connection
    $conn = new mysqli($host, $username, $password, $db_name);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if (isset($_GET['username']) && isset($_GET['userpasswd'])) {
        $ip_address = $_SERVER['REMOTE_ADDR']; // Get user's IP address
        $uid = $_GET['username'];
        $pid = $_GET['userpasswd'];

        // Check current count of attempts from this IP address
        $sql = "SELECT COUNT(*) AS attempt_count FROM login_attempts WHERE ip_address = ? AND attempt_time > (NOW() - INTERVAL 1 HOUR)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $ip_address);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row['attempt_count'] >= $max_attempts) {
            echo "You have reached the maximum number of login attempts. Please try again later.";
        } else {
            // Process the login attempt
            $sql = "SELECT * FROM $tbl_name WHERE username = ? AND password = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $uid, $pid);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                echo "<h4>-- Personal information --</h4><br>";
                while ($user = $result->fetch_assoc()) {
                    echo "****************************************************";
                    echo "<p>Username : " . $user['username'] . "</p>";
                    echo "<p>User ID : " . $user['id'] . "</p>";
                    echo "<p>Password : " . $user['password'] . "</p>";
                    echo "****************************************************";
                }
            } else {
                echo "Invalid username or password";
                // Log the failed attempt
                $sql = "INSERT INTO login_attempts (ip_address, attempt_time) VALUES (?, NOW())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $ip_address);
                $stmt->execute();
            }
        }
        $stmt->close();
    }
    $conn->close();
?>
<br>
<a href="../GetLogin.html">Go back to the login page</a>
</body>
</html>
