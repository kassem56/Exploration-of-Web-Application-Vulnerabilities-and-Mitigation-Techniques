<?php
    $host = "localhost"; // Host name
    $username = "root"; // MySQL username
    $password = ""; // MySQL password
    $db_name = "project_csec"; // Database name
    $tbl_name = "users"; // Table name

    // Check if username and password are set in the URL parameters
    if(isset($_GET['username']) && isset($_GET['userpasswd'])){
        // Create connection
        $conn = new mysqli($host, $username, $password, $db_name);

        // Check connection
        if($conn->connect_error){
            die("Connection failed: " . $conn->connect_error);
        }
        
        // Use prepared statements to prevent SQL Injection
        $stmt = $conn->prepare("SELECT * FROM $tbl_name WHERE username = ? AND password = ?");
        
        // Bind parameters
        $stmt->bind_param("ss", $_GET['username'], $_GET['userpasswd']);
        
        // Execute the query
        $stmt->execute();
        
        // Get the result of the query
        $result = $stmt->get_result();

        if($result->num_rows > 0){
            // Fetching user data
            $user = $result->fetch_assoc();
            echo "****************************************************";
            // Output user information
            echo "<p>"."Username : ". $user['username']. "</p>";
            echo "<p>"."User ID : ". $user['id']. "</p>";
            echo "<p>"."Password : ". $user['password']. "</p>";
            echo "****************************************************";

        } else {
            echo "Invalid username or password";
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
?>
