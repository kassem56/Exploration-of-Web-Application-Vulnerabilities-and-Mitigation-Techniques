<html>
<head>
    <title>Post Login Handle</title>
</head>
<body>
    <?php
        #Get the username from the URL
        $username = $_POST["username"];
        #Get the password from the URL
        $password = $_POST["userpasswd"];
        #Print the user username on the screen
        echo "Welcome $username <br>";
        #Print the user password on the screen
        echo "Your password is $password <br>";
    ?>
    <!-- go back to the login page -->
    <a href="../PostLogin.html">Go back to the login page</a>
</body>
</html>

