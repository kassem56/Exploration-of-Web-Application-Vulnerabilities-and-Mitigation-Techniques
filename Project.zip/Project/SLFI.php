<?php
// A list of allowed pages for inclusion
$allowedPages = [
    'login' => 'GetLogin.html',
];

// Check if the 'page' parameter is set and exists in the whitelist
if (isset($_GET['page']) && array_key_exists($_GET['page'], $allowedPages)) {
    $page = $_GET['page'];
    include($allowedPages[$page]); // Include the file from the whitelist
} else {
    echo 'Welcome to our website! Please select a valid page.';
}

?>
