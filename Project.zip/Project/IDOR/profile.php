<?php
$host = "localhost"; // Host name
$username = "root"; // Mysql username
$password = ""; // Mysql password
$db_name = "project_csec"; // Database name
$tbl_name = "users"; // Table name

$conn = new mysqli($host, $username, $password, $db_name);

// Check connection
if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

$userid = $_GET['userid'];

// Vulnerable SQL statement
$sql = "SELECT * FROM $tbl_name WHERE id='$userid'";

if($result = $conn->query($sql)){
    if($result->num_rows > 0){
        echo "<h4>-- Personal information --</h4>". "<br>";
        while($user = $result->fetch_assoc()){ // fetch_assoc() gives one record at a time
            echo "****************************************************";
            echo "<p>"."Username : ". $user['username']. "</p>";
            echo "<p>"."User ID : ". $user['id']. "</p>";
            echo "<p>"."Password : ". $user['password']. "</p>";
            echo "****************************************************";
        }
    } else {
        echo "Invalid user ID";
    }
} else {
    printf("Query Failed: %s\n", $conn->error);
}
$conn->close();


?>