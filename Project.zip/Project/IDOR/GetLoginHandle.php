<html>
<head>
    <title>GET Login Handle</title>
</head>
<body>
<?php
$host = "localhost"; // Host name
$username = "root"; // Mysql username
$password = ""; // Mysql password
$db_name = "project_csec"; // Database name
$tbl_name = "users"; // Table name

// Check if user ID is set in the URL parameters
    // Create connection
    $conn = new mysqli($host, $username, $password, $db_name);

    // Check connection
    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }
    
    $username = $_GET['username'];

    // Vulnerable SQL statement
    $sql = "SELECT * FROM $tbl_name WHERE username='$username'";

    if($result = $conn->query($sql)){
        if($result->num_rows > 0){
            echo "<h4>-- Personal information --</h4>". "<br>";
            while($user = $result->fetch_assoc()){ // fetch_assoc() gives one record at a time
                header("Location: profile.php?userid=" . $user['id']);
                exit();
            }
        } else {
            echo "Invalid user ID";
        }
    } else {
        printf("Query Failed: %s\n", $conn->error);
    }
    $conn->close();
?>

<!-- Go back to the login page -->
<br>
<a href="../GetLogin.html">Go back to the login page</a>
</body>
</html>
