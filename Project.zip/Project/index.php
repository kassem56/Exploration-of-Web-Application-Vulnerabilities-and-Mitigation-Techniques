<?php
if (isset($_GET['page'])) {
    $page = $_GET['page'];
    include($page); // This is vulnerable to LFI and should be secured as previously discussed
} else {
    echo 'Welcome to our website!';
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>MAJK Restaurant</title>
    <!--Including the CSS File index.css-->
    <link rel="stylesheet" type="text/css" href="index.css" />
    <script>
  document.addEventListener('DOMContentLoaded', function() {
    if (!window.location.search.includes('page=')) {
      window.location.search += window.location.search ? '&page=en' : '?page=en';
    }
  });
</script>

  </head>
  <body>
    <ul class="navbar">
      <li><a href="index.html" class="active">Home</a></li>
      <li><a href="GetLogin.html">Get Login</a></li>
      <li><a href="PostLogin.html">POST Login</a></li>
      <li><a href="XSS/Comments.php">Comments</a></li>
    </ul>

    <div class="content">
      <h2>Welcome to MAJK Restaurant</h2>
      <p>
        Discover the finest flavors from our kitchen, where we blend tradition
        with innovation to create memorable culinary experiences. At MAJK, every
        dish is a masterpiece, carefully crafted to delight your senses.
      </p>

      <h3>Gallery</h3>
      <div class="image-gallery">
        <figure>
          <img src="Images/restaurant.webp" alt="MAJK Restaurant Interior" />
          <figcaption>MAJK Restaurant Interior</figcaption>
        </figure>
        <figure>
          <figcaption>
            <img src="Images/FeaturedDish.webp" alt="Featured Dish" />
            <figcaption>Featured Dish</figcaption>
          </figcaption>
        </figure>
        <figure>
          <img src="Images/ChefsatWork.webp" alt="Our Chefs at Work" />
          <figcaption>Our Chefs at Work</figcaption>
        </figure>
      </div>
      <h2>Our Featured Dish: The Enchanted Garden</h2>
      <figure>
        <figcaption>
          <img
            src="Images/TheEnchantedgarden.webp"
            alt="The Enchanted Garden Dish"
            style="max-width: 400px"
          />
          <figcaption>
            The Enchanted Garden: A symphony of flavors where each ingredient
            tells a tale.
          </figcaption>
        </figcaption>
      </figure>
      <p>
        Embark on a culinary expedition with our featured dish,
        <strong>The Enchanted Garden</strong>. Crafted from the rarest
        ingredients harvested under the moonlight in our mystical garden, this
        dish is a testament to our chefs' prowess in merging the ethereal with
        the earthly.
      </p>

      <p>
        Each bite of The Enchanted Garden is a brushstroke of flavor painting
        your palate with a spectrum of tastes and textures. The base, a velvety
        puree of moon-kissed sweet potatoes, lays the canvas. Atop this, a
        medley of wildcrafted greens, each leaf a whisper of flavors untold,
        dances in harmony. The centerpiece, jewel-toned, crystal-clear vegetable
        pearls, burst with the essence of the garden itself.
      </p>

      <p>
        Adorned with edible flowers and a drizzle of golden, honey-infused
        vinaigrette, The Enchanted Garden is not just a dish; it's a journey
        through the seasons, a celebration of the earth's bounty. It's where the
        magic of MAJK comes to life, inviting you to savor the moment, to
        indulge in the whimsical, and to embrace the extraordinary.
      </p>

      <p>
        Join us at MAJK, where every meal is a story, and every plate is a
        canvas awaiting the touch of our culinary artists. The Enchanted Garden
        awaits to transport you to a realm of flavor beyond your wildest dreams.
      </p>
    </div>
  </body>
</html>
