<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_csec";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare statement
$stmt = $conn->prepare("INSERT INTO Comments (name, comment) VALUES (?, ?)");

// Bind parameters
$stmt->bind_param("ss", $_POST['name'], $_POST['comment']);

// Execute the statement
if ($stmt->execute() === TRUE) {
    header('Location: CommentsSec.php'); // Redirect back to the form page
} else {
    echo "Error: " . $stmt->error;
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
