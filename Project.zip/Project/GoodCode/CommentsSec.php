<!DOCTYPE html>
<html lang="en">
  <head>
    <title>MAJK Restaurant</title>
    <!--Including the CSS File index.css-->
    <link rel="stylesheet" type="text/css" href="../index.css" />
  </head>
<body>
    <ul class="navbar">
      <li><a href="../index.php" class="active">Home</a></li>
      <li><a href="../GetLogin.html">Get Login</a></li>
      <li><a href="../PostLogin.html">POST Login</a></li>
      <li><a href="CommentsSec.php">Comments</a></li>
    </ul>
    <h1 style="text-align: center;">Guest reviews</h1>
    <form action="submit-comment.php" method="POST" style="text-align: center;">
        Name: <input type="text" name="name"><br>
        Comment: <textarea name="comment"></textarea><br>
        <input type="submit" value="Submit">
    </form>

    <!-- Place for displaying comments -->
    <div id="comments" style="text-align: center;">
        <h4 style="font-size: 32px; text-align: center;">Comments</h4>
        <?php
        // Your PHP code for fetching and displaying comments goes here
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "project_csec";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT name, comment FROM Comments ORDER BY submitted_at DESC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output each row
            while($row = $result->fetch_assoc()) {
                echo htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') . ": " . htmlspecialchars($row['comment'], ENT_QUOTES, 'UTF-8') . "<br>";
            }
        } else {
            echo "No comments yet!";
        }

        $conn->close();
        ?>
    </div>
        <!-- a Link to another webpage -->
        <p style="text-align: center;"><a href="../XSS/Comments.php">Unsecure Comments</a></p>
</body>
</html>
